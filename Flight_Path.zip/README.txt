****************************************************************************************************************************************
*IMPORTANT: YOU MUST TAKE THE APPLICATION (Flight_Path) and THE GLOBAL MAPPER SCRIPT (Text_to_Sahpe_NAD83_2011) AND RUN THEM LOCALLY   *
*TLDR:																       *
**DO NOT RUN ON LIDAR01														       *
**Copy the path in the widow that apphears and paste it in the browser that appears						       *
**You must have both Flight_Path and Text_to_Sahpe_NAD83_2011 in the same location to run this script   			       *
****************************************************************************************************************************************

The Flight_Path will need a folder of text files for inupt for our sake we will call this INPUT_FOLDER.
The best way to run this program is to take INPUT_FOLDER and drag it on top of  Flight_Path.
If the program quits without a second widow opening delete the fixed folder and find any text files that end in _CVS and delete them.

You must have global maper installed on your device to run this.

There is a copy of the application that is the python source code it is not necessary to run the Flight_Path application.
****************************************************************************************************************************************
Last Edit: Grant Copple; June 9th, 2020; 
****************************************************************************************************************************************
If you need a new copy of anything go to https://github.com/Gcopple/Text_To_Shape.git